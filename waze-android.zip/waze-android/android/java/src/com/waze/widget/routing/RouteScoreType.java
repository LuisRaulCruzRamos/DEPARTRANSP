package com.waze.widget.routing;

public enum RouteScoreType {NONE, ROUTE_BAD, ROUTE_OK, ROUTE_GOOD}