package com.waze.widget;

//import com.waze.R.id;
//import com.waze.R.layout;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

public class WazeAppWidgetCfgActivity extends Activity {
	
	@Override
	protected void onCreate( Bundle savedInstanceState ) {
		super.onCreate( savedInstanceState );
		// get the appWidgetId of the appWidget being configured

	}
	
	public static Context _CONTEXT = null;
//	private int mAppWidgetId;
}
