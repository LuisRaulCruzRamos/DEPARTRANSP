package com.waze.widget.routing;

public enum RoutingType {NONE, DISTANCE, TIME, HISTORIC_TIME}
