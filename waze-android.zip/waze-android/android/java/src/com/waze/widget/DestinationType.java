package com.waze.widget;

public enum DestinationType {HOME, WORK, NONE, NA};
